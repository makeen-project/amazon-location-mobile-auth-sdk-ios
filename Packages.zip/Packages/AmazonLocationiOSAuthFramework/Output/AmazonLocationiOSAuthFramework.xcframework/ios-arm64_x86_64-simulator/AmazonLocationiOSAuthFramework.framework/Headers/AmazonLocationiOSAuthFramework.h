//
//  AmazonLocationiOSAuthFramework.h
//  AmazonLocationiOSAuthFramework
//
//  Created by Zeeshan Sheikh on 08/07/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for AmazonLocationiOSAuthFramework.
FOUNDATION_EXPORT double AmazonLocationiOSAuthFrameworkVersionNumber;

//! Project version string for AmazonLocationiOSAuthFramework.
FOUNDATION_EXPORT const unsigned char AmazonLocationiOSAuthFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AmazonLocationiOSAuthFramework/PublicHeader.h>


